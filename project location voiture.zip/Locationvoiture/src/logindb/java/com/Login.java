package logindb.java.com;
import java.awt.EventQueue;




import javax.swing.JFrame;
import javax.swing.JTextField;

import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.Image;
import java.awt.Window;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;
import java.awt.Color;
import java.awt.Component;
public class Login {

	private JFrame Login1;
	private JTextField textid;
	private JPasswordField textpass;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login window = new Login();
					window.Login1.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Login() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		Login1 = new JFrame();
		Login1.getContentPane().setBackground(new Color(153, 153, 255));
		Login1.setBounds(100, 100, 668, 429);
		Login1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Login1.getContentPane().setLayout(null);
		
		textid = new JTextField();
		textid.setBounds(229, 78, 264, 34);
		Login1.getContentPane().add(textid);
		textid.setColumns(10);
		
		JLabel firstlable = new JLabel("ID:");
		firstlable.setForeground(new Color(255, 255, 255));
		firstlable.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 21));
		firstlable.setBounds(182, 81, 79, 19);
		Login1.getContentPane().add(firstlable);
		
		JLabel lblNewLabel_1 = new JLabel("PASSWORD:");
		lblNewLabel_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 21));
		lblNewLabel_1.setBounds(94, 169, 146, 16);
		Login1.getContentPane().add(lblNewLabel_1);
		
		JButton btlogin = new JButton("login");
		btlogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
									try {
						Class.forName("com.mysql.jdbc.Driver");
						Connection com =DriverManager.getConnection("jdbc:mysql://localhost:3306/locationvoiture","root","");
						Statement st=(Statement) com.createStatement();
						String sql="Select* from emps where id='"+textid.getText()+"'and pss='"+textpass.getText().toString()+"'";
						ResultSet rs=(ResultSet) st.executeQuery(sql);
						if(rs.first()) {
						JOptionPane.showMessageDialog(null, "login succ");
						Class.forName("com.mysql.jdbc.Driver");
						Inter window = new Inter();
						window.Inter1.setVisible(true);
						
						
							 
							 
							  
						}
						else {
							JOptionPane.showMessageDialog(null, "login failed");
						}
						
						
	                    }catch (ClassNotFoundException | SQLException e) {
						e.printStackTrace();

		}

		}
				
		}	
		
		);
		btlogin.setFont(new Font("Dubai Medium", Font.PLAIN, 21));
		btlogin.setBounds(310, 249, 85, 34);
		Login1.getContentPane().add(btlogin);
		
		textpass = new JPasswordField();
		textpass.setBounds(229, 165, 264, 34);
		Login1.getContentPane().add(textpass);
		
		Component img=Login1.getContentPane().add(new JLabel(new ImageIcon("D:/2CS/2 SEM/vis par ordinateur/tp1/pic1.jpg")));
		img.setBounds(0, 0, 700, 700);
	}
}
