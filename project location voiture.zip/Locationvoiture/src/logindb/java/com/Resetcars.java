package logindb.java.com;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class Resetcars {

	JFrame Rescar;
	private JTextField t1;
	private JTextField t2;
	public static String a;
	public static String b;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Resetcars window = new Resetcars();
					window.Rescar.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Resetcars() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		Rescar = new JFrame();
		Rescar.getContentPane().setBackground(new Color(153, 153, 255));
		Rescar.setBounds(100, 100, 465, 418);
		Rescar.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Rescar.getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("confirm ");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				
					a=t1.getText();
					b=t2.getText();
					//System.out.println(a);
					//System.out.println(b);
					
					Facture window = new Facture();
					window.fac.setVisible(true);
				
					
                  
				
			}});
		btnNewButton.setBounds(173, 314, 85, 21);
		Rescar.getContentPane().add(btnNewButton);
		
		JLabel lblNewLabel = new JLabel("MAT:");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 21));
		lblNewLabel.setBounds(97, 97, 85, 27);
		Rescar.getContentPane().add(lblNewLabel);
		
		t1 = new JTextField();
		t1.setBounds(173, 101, 96, 19);
		Rescar.getContentPane().add(t1);
		t1.setColumns(10);
		
		
		t2 = new JTextField();
		t2.setBounds(173, 177, 96, 19);
		Rescar.getContentPane().add(t2);
		t2.setColumns(10);
		
		
		JLabel lblNewLabel_1 = new JLabel("CIN:");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 21));
		lblNewLabel_1.setBounds(97, 176, 96, 21);
		Rescar.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("reset cars");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 23));
		lblNewLabel_2.setBounds(173, 10, 113, 47);
		Rescar.getContentPane().add(lblNewLabel_2);
	}
}
