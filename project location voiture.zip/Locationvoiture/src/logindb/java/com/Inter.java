package logindb.java.com;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class Inter {

	JFrame Inter1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Inter window = new Inter();
					window.Inter1.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Inter() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		Inter1 = new JFrame();
		Inter1.getContentPane().setBackground(new Color(153, 153, 255));
		Inter1.getContentPane().setForeground(Color.BLACK);
		Inter1.setBounds(100, 100, 453, 313);
		Inter1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Inter1.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Add car");
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 21));
		lblNewLabel.setBounds(15, 70, 98, 29);
		Inter1.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Delete cars");
		lblNewLabel_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 21));
		lblNewLabel_1.setBounds(15, 131, 191, 67);
		Inter1.getContentPane().add(lblNewLabel_1);
		
		JButton btnNewButton = new JButton("louer");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Manipulation_voiture window = new Manipulation_voiture();
				window.mani1.setVisible(true);
				
				
			}
		});
		btnNewButton.setBounds(158, 78, 143, 21);
		Inter1.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("view cars\r\n");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Resetcars window =  new Resetcars();
				window.Rescar.setVisible(true);
				
			}
		});
		btnNewButton_1.setBounds(158, 158, 143, 21);
		Inter1.getContentPane().add(btnNewButton_1);
		
	}

}
