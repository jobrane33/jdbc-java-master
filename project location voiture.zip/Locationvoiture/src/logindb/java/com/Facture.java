package logindb.java.com;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JTextPane;

import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;

import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JRadioButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class Facture {

	JFrame fac;
	private JTextField t1;
	private JTextField t2;
	private JTextField t3;
	private float p;
	private float i;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Facture window = new Facture();
					window.fac.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Facture() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		fac = new JFrame();
		fac.getContentPane().setBackground(new Color(153, 153, 255));
		fac.setBounds(100, 100, 467, 435);
		fac.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		fac.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("facture");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 22));
		lblNewLabel.setBounds(185, 24, 185, 27);
		fac.getContentPane().add(lblNewLabel);
		
		JButton btnNewButton = new JButton("confirm\r\n");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				
				try {
					
					Class.forName("com.mysql.jdbc.Driver");
					Connection com =DriverManager.getConnection("jdbc:mysql://localhost:3306/locationvoiture","root","");
					String sql="delete from  loc where mat='"+t2.getText()+"'and cin='"+t1.getText()+"'";
					PreparedStatement pst =com.prepareStatement(sql);
					pst.execute();
					JOptionPane.showMessageDialog(null, "deleted");
					
					Inter window =  new Inter();
					window.Inter1.setVisible(true);
					
                    }catch (ClassNotFoundException | SQLException e) {
					e.printStackTrace();
				
				
			}
			}});
		btnNewButton.setBounds(217, 374, 85, 21);
		fac.getContentPane().add(btnNewButton);
		
		t1 = new JTextField();
		t1.setEnabled(false);
		t1.setBounds(122, 93, 96, 19);
		fac.getContentPane().add(t1);
		t1.setColumns(10);
		t1.setText(Resetcars.b);
		t2 = new JTextField();
		t2.setEnabled(false);
		t2.setBounds(122, 150, 96, 19);
		fac.getContentPane().add(t2);
		t2.setColumns(10);
		t2.setText(Resetcars.a);
		
		
		t3 = new JTextField();
		t3.setEnabled(false);
		t3.setBounds(122, 218, 96, 19);
		fac.getContentPane().add(t3);
		t3.setColumns(10);
		
		JRadioButton rdbtnNewRadioButton = new JRadioButton("par carte");
		rdbtnNewRadioButton.setBackground(new Color(153, 153, 255));
		rdbtnNewRadioButton.setBounds(54, 277, 103, 21);
		fac.getContentPane().add(rdbtnNewRadioButton);
		
		JRadioButton rdbtnNewRadioButton_1 = new JRadioButton("lequide ");
		rdbtnNewRadioButton_1.setBackground(new Color(153, 153, 255));
		rdbtnNewRadioButton_1.setBounds(199, 277, 103, 21);
		fac.getContentPane().add(rdbtnNewRadioButton_1);
		
		JLabel lblNewLabel_1 = new JLabel("cin  client");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblNewLabel_1.setBounds(16, 94, 79, 16);
		fac.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("mat voiture");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_2.setBounds(16, 132, 96, 61);
		fac.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("price");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_3.setBounds(16, 221, 79, 16);
		fac.getContentPane().add(lblNewLabel_3);
		
		JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("cheque ");
		rdbtnNewRadioButton_2.setBackground(new Color(153, 153, 255));
		rdbtnNewRadioButton_2.setBounds(344, 277, 103, 21);
		fac.getContentPane().add(rdbtnNewRadioButton_2);
		
		JButton btnNewButton_1 = new JButton("view price");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection com =DriverManager.getConnection("jdbc:mysql://localhost:3306/locationvoiture","root","");
					java.sql.Statement st= com.createStatement();
					String sql="Select* from vehicule where mat='"+t2.getText()+"'";
					
					ResultSet rs=(ResultSet) st.executeQuery(sql);
					
					
					
					while(rs.next()) {
						
						
						String prix=rs.getString("prix_jour");
						
						p= Float.parseFloat(prix);
						
						
					    
					    
						
					}
				
					
                    }catch (ClassNotFoundException | SQLException e) {
					e.printStackTrace();

	}
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection com =DriverManager.getConnection("jdbc:mysql://localhost:3306/locationvoiture","root","");
					java.sql.Statement st= com.createStatement();
					String sql="Select* from loc  where mat='"+t2.getText()+"'";
					
					ResultSet rs=(ResultSet) st.executeQuery(sql);
					
					while(rs.next()) {
						
						
						String nbj=rs.getString("nbjour");
						
						 i= Float.parseFloat(nbj);
						 
						
						
						
					    
					    
						
					}
					
				p=p*i;
				
				String k=String.valueOf(p);
				t3.setText(k);
					
                    }catch (ClassNotFoundException | SQLException e) {
					e.printStackTrace();

	}
				
					
					
	
				
						  
					}
					
					
					
                   
			
			});
		btnNewButton_1.setBounds(122, 374, 95, 21);
		fac.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("imrprimer");
		btnNewButton_2.setBounds(344, 374, 99, 21);
		fac.getContentPane().add(btnNewButton_2);
	}
}
