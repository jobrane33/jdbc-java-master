package logindb.java.com;

import java.awt.EventQueue;


import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;

import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class Client {

	JFrame PPP;
	private JTextField textcin;
	private JTextField tname;
	private JTextField tfamily;
	private JTextField tdate;
	private JTextField tphone;
	private JTextField temail;
	public static String x;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Client window = new Client();
					window.PPP.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Client() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		PPP = new JFrame();
		PPP.getContentPane().setBackground(new Color(153, 153, 255));
		PPP.setBounds(100, 100, 530, 698);
		PPP.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		PPP.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("CIN:");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel.setBounds(35, 133, 45, 13);
		PPP.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("name:");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_1.setBounds(35, 190, 45, 13);
		PPP.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("family name:");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_2.setBounds(35, 240, 89, 27);
		PPP.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("birth date :");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_3.setBounds(35, 304, 89, 13);
		PPP.getContentPane().add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("phone number:");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_4.setBounds(35, 360, 107, 27);
		PPP.getContentPane().add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("Email:");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_5.setBounds(35, 424, 96, 27);
		PPP.getContentPane().add(lblNewLabel_5);
		
		textcin = new JTextField();
		textcin.setEnabled(false);
		textcin.setBounds(165, 124, 144, 36);
		PPP.getContentPane().add(textcin);
		textcin.setColumns(10);
		textcin.setText(Manipulation_voiture.y);
		
		tname = new JTextField();
		tname.setBounds(165, 181, 144, 36);
		PPP.getContentPane().add(tname);
		tname.setColumns(10);
		
		tfamily = new JTextField();
		tfamily.setBounds(165, 238, 144, 36);
		PPP.getContentPane().add(tfamily);
		tfamily.setColumns(10);
		
		tdate = new JTextField();
		tdate.setBounds(165, 295, 144, 36);
		PPP.getContentPane().add(tdate);
		tdate.setColumns(10);
		
		tphone = new JTextField();
		tphone.setBounds(165, 358, 144, 36);
		PPP.getContentPane().add(tphone);
		tphone.setColumns(10);
		
		temail = new JTextField();
		temail.setBounds(165, 422, 144, 36);
		PPP.getContentPane().add(temail);
		temail.setColumns(10);
		
		JLabel lblNewLabel_6 = new JLabel("insert client");
		lblNewLabel_6.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 25));
		lblNewLabel_6.setBounds(152, 42, 221, 36);
		PPP.getContentPane().add(lblNewLabel_6);
		
		JButton btnNewButton = new JButton("save");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					x=textcin.getText();
					
					Class.forName("com.mysql.jdbc.Driver");
					Connection com =DriverManager.getConnection("jdbc:mysql://localhost:3306/locationvoiture","root","");
					
					String sql="insert into client (cin,name,family_name,birth_date,phone,email)"+"values (?,?,?,?,?,?)";
					PreparedStatement preparedStmt =com.prepareStatement(sql);
					preparedStmt.setString (1, textcin.getText());
				      preparedStmt.setString (2, tname.getText());
				      preparedStmt.setString (3, tfamily.getText());
				      preparedStmt.setString(4, tdate.getText());
				      preparedStmt.setString(5,tphone.getText());  
				      preparedStmt.setString(6, temail.getText());
				      preparedStmt.execute();
				      Statement st=(Statement) com.createStatement();
						String sql2="Select* from client";
						ResultSet rs=(ResultSet) st.executeQuery(sql2);
						if(rs.first()) {
						JOptionPane.showMessageDialog(null, "inster complete");
						Class.forName("com.mysql.jdbc.Driver");
						Manipulation_voiture window = new Manipulation_voiture();
						window.mani1.setVisible(true);
				      
						}} catch (ClassNotFoundException | SQLException e) {
					e.printStackTrace();

		}
			}
		});
		btnNewButton.setBounds(198, 497, 85, 21);
		PPP.getContentPane().add(btnNewButton);
	}
}
