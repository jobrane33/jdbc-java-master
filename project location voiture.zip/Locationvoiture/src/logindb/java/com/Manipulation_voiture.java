package logindb.java.com;

import java.awt.Component;
import java.awt.EventQueue;




import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.text.Caret;

import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;

import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.awt.event.ActionEvent;
import javax.swing.JRadioButton;
import java.sql.*;
import java.awt.Color;
import java.awt.SystemColor;

public class Manipulation_voiture {

	JFrame mani1;
	private JTextField textcolordispo;
	private JTextField textdateloc;
	private JTextField textprix;
	private JTextField textcarburant;
	private JTextField textmat;
	private JTextField texttype;
	private JTextField tgetcin;
	private JTextField tnbjour;
	public static String y;
	public static String m;
	
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Manipulation_voiture window = new Manipulation_voiture();
					window.mani1.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Manipulation_voiture() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private JFrame initialize() {
		mani1 = new JFrame();
		mani1.getContentPane().setBackground(SystemColor.control);
		mani1.getContentPane().setFont(new Font("Tahoma", Font.PLAIN, 21));
		mani1.setBounds(100, 100, 863, 766);
		mani1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		mani1.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("louer voiture ");
		lblNewLabel.setFont(new Font("Yu Gothic Medium", Font.BOLD | Font.ITALIC, 56));
		lblNewLabel.setBounds(252, 10, 437, 91);
		mani1.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("marque:");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 21));
		lblNewLabel_1.setVerticalAlignment(SwingConstants.BOTTOM);
		lblNewLabel_1.setBounds(36, 123, 112, 31);
		mani1.getContentPane().add(lblNewLabel_1);
		
		JComboBox marquebox = new JComboBox();
		marquebox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection com =DriverManager.getConnection("jdbc:mysql://localhost:3306/locationvoiture","root","");
					java.sql.Statement st= com.createStatement();
					String sql="Select* from vehicule where marque='"+marquebox.getSelectedItem()+"'and dipso=1";
					ResultSet rs=(ResultSet) st.executeQuery(sql);
					
					while(rs.next()) {
						String couleur=rs.getString("couleur");
						String mat=rs.getString("MAT");
						String prix=rs.getString("prix_jour");
						String type=rs.getString("type");
					    String carb=rs.getString("carburant");
					    m=prix;
					    
						
						textmat.setText(mat);
						textprix.setText(prix);
						texttype.setText(type);
						textcarburant.setText(carb);
						
						
						textcolordispo.setText(couleur);
						String x=textmat.getText();
						String y=textcolordispo.getText();
						if(x.equals(y)==true) {
							JOptionPane.showMessageDialog(null, "no car for this model");
						}
					}
					
					
                    }catch (ClassNotFoundException | SQLException e) {
					e.printStackTrace();

	}

	}
			
	
	
			
		});
		marquebox.setModel(new DefaultComboBoxModel(new String[] {"choisie un model ", "mercedes_benz", "renault ", "bmw ", "cherry"}));
		marquebox.setToolTipText("choisire marque\r\n");
		marquebox.setBounds(205, 136, 117, 19);
		mani1.getContentPane().add(marquebox);
		
		JLabel lblNewLabel_2 = new JLabel("couleur dispo");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 21));
		lblNewLabel_2.setBounds(36, 239, 185, 23);
		mani1.getContentPane().add(lblNewLabel_2);
		
		textcolordispo = new JTextField();
		textcolordispo.setEditable(false);
		textcolordispo.setBounds(205, 239, 344, 31);
		mani1.getContentPane().add(textcolordispo);
		textcolordispo.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("couleur:");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 21));
		lblNewLabel_3.setBounds(36, 380, 85, 31);
		mani1.getContentPane().add(lblNewLabel_3);
		
		JComboBox listcolor = new JComboBox();
		listcolor.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd");  
				   LocalDateTime now = LocalDateTime.now();  
				   textdateloc.setText(dtf.format(now).toString());
                  String s1=(String) listcolor.getSelectedItem();
                  String s2=(String) textcolordispo.getText();
                  {if(s1.equals(s2)==false) 
					JOptionPane.showMessageDialog(null, "couleur non disponible");
                  
			}  
			}   
			
		});
		listcolor.setModel(new DefaultComboBoxModel(new String[] {"pick a color", "NOIR", "GRIS", "BLANC", "BLUE", "ROUGE"}));
		listcolor.setBounds(205, 388, 117, 22);
		mani1.getContentPane().add(listcolor);
		
		JButton btnconfirm = new JButton("confirm\r\n");
		btnconfirm.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					y=tgetcin.getText();
					Class.forName("com.mysql.jdbc.Driver");
					Connection com =DriverManager.getConnection("jdbc:mysql://localhost:3306/locationvoiture","root","");
					Statement st=(Statement) com.createStatement();
					String sql="Select* from  client where CIN='"+tgetcin.getText()+"'";
					ResultSet rs=(ResultSet) st.executeQuery(sql);
					
					if(rs.next()==false){
						Client window = new Client();
						window.PPP.setVisible(true);
						Class.forName("com.mysql.jdbc.Driver");
						Connection f2 =DriverManager.getConnection("jdbc:mysql://localhost:3306/locationvoiture","root","");
						
						String sql4="insert into loc(cin,mat,date,nbjour)"+"values (?,?,?,?)";
						PreparedStatement preparedStmt =f2.prepareStatement(sql4);
						preparedStmt.setString (1,tgetcin.getText());
						preparedStmt.setString (2,textmat.getText());
						preparedStmt.setString (3,textdateloc.getText());
						preparedStmt.setString (4,tnbjour.getText());
						JOptionPane.showMessageDialog(null, "car rent!");
						
					}
						else {
							try {
								Class.forName("com.mysql.jdbc.Driver");
								Connection f =DriverManager.getConnection("jdbc:mysql://localhost:3306/locationvoiture","root","");
								
								String sql1="insert into loc(cin,mat,date,nbjour)"+"values (?,?,?,?)";
								PreparedStatement preparedStmt =f.prepareStatement(sql1);
								preparedStmt.setString (1,tgetcin.getText());
								preparedStmt.setString (2,textmat.getText());
								preparedStmt.setString (3,textdateloc.getText());
								preparedStmt.setString (4,tnbjour.getText());
								JOptionPane.showMessageDialog(null, "car rent!");
								
								
								
								
							    
							      
							      preparedStmt.execute();
							      
							      
									} catch (ClassNotFoundException | SQLException e) {
								e.printStackTrace();

					}
							
						}
				}
				 catch (ClassNotFoundException |SQLException e) {
					e.printStackTrace();
				}
				
			
				
				
			}
		});
		btnconfirm.setBounds(362, 671, 85, 21);
		mani1.getContentPane().add(btnconfirm);
		
		JLabel lblNewLabel_4 = new JLabel("date location:");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.PLAIN, 21));
		lblNewLabel_4.setBounds(63, 556, 126, 19);
		mani1.getContentPane().add(lblNewLabel_4);
		
		textdateloc = new JTextField();
		textdateloc.setEditable(false);
		textdateloc.setBounds(205, 533, 132, 73);
		mani1.getContentPane().add(textdateloc);
		textdateloc.setColumns(10);
		
		textprix = new JTextField();
		textprix.setEditable(false);
		textprix.setBounds(205, 286, 344, 31);
		mani1.getContentPane().add(textprix);
		textprix.setColumns(10);
		
		JLabel lblNewLabel_5 = new JLabel("prix jour");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.PLAIN, 21));
		lblNewLabel_5.setBounds(36, 282, 107, 31);
		mani1.getContentPane().add(lblNewLabel_5);
		
		textcarburant = new JTextField();
		textcarburant.setEditable(false);
		textcarburant.setBounds(205, 450, 344, 31);
		mani1.getContentPane().add(textcarburant);
		textcarburant.setColumns(10);
		
		textmat = new JTextField();
		textmat.setEditable(false);
		textmat.setBounds(205, 190, 344, 31);
		mani1.getContentPane().add(textmat);
		textmat.setColumns(10);
		
		JLabel lblNewLabel_6 = new JLabel("matricule");
		lblNewLabel_6.setFont(new Font("Tahoma", Font.PLAIN, 21));
		lblNewLabel_6.setBounds(36, 199, 108, 22);
		mani1.getContentPane().add(lblNewLabel_6);
		
		texttype = new JTextField();
		texttype.setEditable(false);
		texttype.setBounds(205, 339, 344, 27);
		mani1.getContentPane().add(texttype);
		texttype.setColumns(10);
		
		JLabel lblNewLabel_7 = new JLabel("type");
		lblNewLabel_7.setFont(new Font("Tahoma", Font.PLAIN, 21));
		lblNewLabel_7.setBounds(36, 339, 108, 31);
		mani1.getContentPane().add(lblNewLabel_7);
		
		JLabel lblNewLabel_8 = new JLabel("carburant");
		lblNewLabel_8.setFont(new Font("Tahoma", Font.PLAIN, 21));
		lblNewLabel_8.setBounds(36, 453, 108, 19);
		mani1.getContentPane().add(lblNewLabel_8);
		
		JButton btnsave = new JButton("save");
		btnsave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					int a=0;
					Class.forName("com.mysql.jdbc.Driver");
					Connection com =DriverManager.getConnection("jdbc:mysql://localhost:3307/locationvoiture","root","");
					String sql="update  vehicule set dipso='"+a+"'where MAT='"+textmat.getText()+"'";
					PreparedStatement pst =com.prepareStatement(sql);
					pst.execute();
					JOptionPane.showMessageDialog(null, "update succ");
					
				
					
                    }catch (ClassNotFoundException | SQLException e) {
					e.printStackTrace();
 
	}
				
				
			}
		});
		btnsave.setBounds(252, 671, 85, 21);
		mani1.getContentPane().add(btnsave);
		
		tgetcin = new JTextField();
		tgetcin.setBounds(502, 136, 173, 21);
		mani1.getContentPane().add(tgetcin);
		tgetcin.setColumns(10);
		tgetcin.setText(Client.x);
		
		
		JLabel lblNewLabel_9 = new JLabel("CIN client");
		lblNewLabel_9.setFont(new Font("Tahoma", Font.PLAIN, 21));
		lblNewLabel_9.setBounds(384, 126, 112, 31);
		mani1.getContentPane().add(lblNewLabel_9);
		
		tnbjour = new JTextField();
		tnbjour.setBounds(205, 501, 96, 19);
		mani1.getContentPane().add(tnbjour);
		tnbjour.setColumns(10);
		
		JLabel lblNewLabel_10 = new JLabel("nb jours");
		lblNewLabel_10.setFont(new Font("Tahoma", Font.PLAIN, 21));
		lblNewLabel_10.setBounds(36, 491, 102, 31);
		mani1.getContentPane().add(lblNewLabel_10);
		
		JButton btnNewButton = new JButton("back ");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Inter window =  new Inter();
				window.Inter1.setVisible(true);
				
				
			}
		});
		Component img1=mani1.getContentPane().add(new JLabel(new ImageIcon("D:/2CS/2 SEM/vis par ordinateur/tp1/pic3.jpg")));
		img1.setBounds(-40, 40, 900, 850);
		btnNewButton.setBounds(736, 135, 85, 21);
		mani1.getContentPane().add(btnNewButton);
		return mani1;
		
		
		
	}
	
}
