package logindb.java.com;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTextField;

import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.ResultSetMetaData;
import com.mysql.jdbc.Statement;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JTextPane;
import javax.swing.JTable;

public class CarViwer extends OutputStream {

	private JFrame frame;
	private  OutputStream x;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public CarViwer(OutputStream x) {
		this.x=x;
	}
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CarViwer window = new CarViwer();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public CarViwer() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 879, 590);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("active rents");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel.setBounds(356, 10, 140, 33);
		frame.getContentPane().add(lblNewLabel);
		
		JButton btnNewButton = new JButton("view");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String s = "1" ;
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection com =DriverManager.getConnection("jdbc:mysql://localhost:3306/locationvoiture","root","");
					Statement st=(Statement) com.createStatement();
					String sql="Select* from loc ";
					ResultSet rs=(ResultSet) st.executeQuery(sql);
					ResultSetMetaData resultMeta = (ResultSetMetaData) rs.getMetaData();
					System.out.println("\n*****************************************************************");
					 
					 for(int i = 1; i <= resultMeta.getColumnCount(); i++)
					 System.out.print("\t" + resultMeta.getColumnName(i).toUpperCase() + "\t *");

					 System.out.println("\n*******************************************************************");

					 while(rs.next()){
					 for(int i = 1; i <= resultMeta.getColumnCount(); i++)
					 System.out.print("\t" + rs.getObject(i).toString() + "\t |");

					 System.out.println("\n-----------------------------------------------------------------");
					 }
					 rs.close();
					 st.close();
					 
					
						 
							 
							 
							 
						 
					
					
					
						 
						 
						  
					
					
					
					}catch (ClassNotFoundException | SQLException e) {
					e.printStackTrace();

	}

			}
		});
		btnNewButton.setBounds(391, 522, 85, 21);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("back to menue");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Inter window =  new Inter();
				window.Inter1.setVisible(true);
				
			}
		});
		btnNewButton_1.setBounds(486, 522, 140, 21);
		frame.getContentPane().add(btnNewButton_1);
		
		table = new JTable();
		table.setBounds(682, 382, -497, -259);
		frame.getContentPane().add(table);
	}

	@Override
	public void write(int arg0) throws IOException {
		// TODO Auto-generated method stub
		
	}
}
